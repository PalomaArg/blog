/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import dominio.Admor;
import dominio.Anclado;
import dominio.Comun;
import java.util.List;

/**
 *
 * @author palom
 */
public class CtrlAdmor {
    FachadaNegocios fn = new FachadaNegocios();
    
    public void guardar(Admor admor){
        fn.guardarAdmor(admor);
    }    
    
    public Admor consultarAdmor(Admor obj){
        return fn.consultarAdmor(obj);
    }
    
    public List<Admor> consultarAdmors(){
        return fn.consultarAdmors();
    }
    
    public void publicarAnclado(Anclado obj){
        fn.guardarAnclado(obj);
    }
    
    public void publicarComun(Comun obj){
        fn.guardarComun(obj);
    }
    
    public void eliminarAnclado(Anclado obj){
        fn.borrarAnclado(obj);
    }
    
}
