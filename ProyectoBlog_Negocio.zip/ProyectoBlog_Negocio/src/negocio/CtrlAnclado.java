/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import dominio.Anclado;
import java.util.List;

/**
 *
 * @author palom
 */
public class CtrlAnclado {
    FachadaNegocios fn = new FachadaNegocios();
    
    public void guardar(Anclado anclado){
        fn.guardarAnclado(anclado);
    }    
    
    public Anclado consultarAnclado(Anclado obj){
        return fn.consultarAnclado(obj);
    }
    
    public List<Anclado> consultarAnclados(){
        return fn.consultarAnclados();
    }
}
