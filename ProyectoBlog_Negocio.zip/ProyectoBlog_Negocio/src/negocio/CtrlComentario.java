/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import dominio.Comentario;
import java.util.List;

/**
 *
 * @author palom
 */
public class CtrlComentario {
    FachadaNegocios fn = new FachadaNegocios();
    
    public void guardar(Comentario comentario){
        fn.guardarComentario(comentario);
    }    
    
    public Comentario consultarComentario(Comentario obj){
        return fn.consultarComentario(obj);
    }
    
    public List<Comentario> consultarComentarios(){
        return fn.consultarComentarios();
    }
}
