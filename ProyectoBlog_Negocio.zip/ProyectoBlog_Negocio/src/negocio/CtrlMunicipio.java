/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import dominio.Municipio;
import java.util.List;

/**
 *
 * @author palom
 */
public class CtrlMunicipio {
    
     FachadaNegocios fn = new FachadaNegocios();
     
     public Municipio consultarMunicipio(Municipio obj) {
        return fn.consultarMunicipio(obj);
    }

    public List<Municipio> consultarMunicipios() {
        return fn.consultarMunicipios();
    }
}
