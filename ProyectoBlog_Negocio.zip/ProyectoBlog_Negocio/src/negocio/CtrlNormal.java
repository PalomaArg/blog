/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import dominio.Comentario;
import dominio.Comun;
import dominio.Normal;
import java.util.List;

/**
 *
 * @author palom
 */
public class CtrlNormal {
    FachadaNegocios fn = new FachadaNegocios();
    
    public void guardar(Normal normal){
        fn.guardarNormal(normal);
    }
    
    public void guardarComentario(Comentario obj){
        fn.guardarComentario(obj);
    }
    
    public void guardarComun(Comun obj){
        fn.guardarComun(obj);
    }
    
    public Normal consultarNormal(Normal obj){
        return fn.consultarNormal(obj);
    }
    
    public List<Normal> consultarNormales(){
        return fn.consultarNormales();
    }
    
    public void editarComunNormal(Comun obj){
        fn.editarComunNormal(obj);
    }
}
