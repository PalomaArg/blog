/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

/**
 *
 * @author palom
 */
public class FabricaNegocios {

    private CtrlAdmor admor;
    private CtrlComentario com;
    private CtrlComun comun;
    private CtrlAnclado anc;
    private CtrlNormal nor;
    private CtrlMunicipio mun;
    private CtrlEstado est;
    
    /**
     * Método que permite recuperar el controlador de Admor
     *
     * @return Controlador Admor
     */
    public CtrlAdmor getCtrlAdmor() {
        if (admor != null) {
            return admor;
        } else {
            admor = new CtrlAdmor();
            return admor;
        }
    }
    
        /**
     * Método que permite recuperar el controlador de Comentario
     *
     * @return Controlador Comentario
     */
    public CtrlComentario getCtrlComentario() {
        if (com != null) {
            return com;
        } else {
            com = new CtrlComentario();
            return com;
        }
    }

    /**
     * Método que permite recuperar el controlador de Comun
     *
     * @return Controlador Comun
     */
    public CtrlComun getCtrlComun() {
        if (comun != null) {
            return comun;
        } else {
            comun = new CtrlComun();
            return comun;
        }
    }
    
    /**
     * Método que permite recuperar el controlador de Anclado
     *
     * @return Controlador Anclado
     */
    public CtrlAnclado getCtrlAnclado() {
        if (anc != null) {
            return anc;
        } else {
            anc = new CtrlAnclado();
            return anc;
        }
    }
    
    /**
     * Método que permite recuperar el controlador de Anclado
     *
     * @return Controlador Anclado
     */
    public CtrlNormal getCtrlNormal() {
        if (nor != null) {
            return nor;
        } else {
            nor = new CtrlNormal();
            return nor;
        }
    }
    
    /**
     * Método que permite recuperar el controlador de Anclado
     *
     * @return Controlador Anclado
     */
    public CtrlMunicipio getCtrlMunicipio() {
        if (mun != null) {
            return mun;
        } else {
            mun = new CtrlMunicipio();
            return mun;
        }
    }
    
    /**
     * Método que permite recuperar el controlador de Anclado
     *
     * @return Controlador Anclado
     */
    public CtrlEstado getCtrlEstado() {
        if (est != null) {
            return est;
        } else {
            est = new CtrlEstado();
            return est;
        }
    }
    
    
    
}
