package negocio;

import accDatos.FabricaDatos;
import accDatos.RepAdmor;
import accDatos.RepAnclado;
import accDatos.RepComentario;
import accDatos.RepComun;
import accDatos.RepEstado;
import accDatos.RepMunicipio;
import accDatos.RepNormal;
import dominio.Admor;
import dominio.Anclado;
import dominio.Comentario;
import dominio.Comun;
import dominio.Estado;
import dominio.Municipio;
import dominio.Normal;
import java.util.List;

/**
 *
 * @author palom
 */
public class FachadaNegocios implements iNegocios {

    FabricaDatos fd = new FabricaDatos();
    RepAdmor admor = fd.getRepAdmor();
    RepAnclado anclado = fd.getRepAnclado();
    RepComentario comentario = fd.getRepComentario();
    RepComun comun = fd.getRepComun();
    RepNormal normal = fd.geRepNormal();
    RepEstado estado = fd.getRepEstado();
    RepMunicipio municipio = fd.getRepMunicipio();
    
    public FachadaNegocios (){
        //aquí se supone que se deben de inicializar
    }

    @Override
    public void guardarComentario(Comentario obj) {
        comentario.guardar(obj);
    }

    @Override
    public void guardarComun(Comun obj) {
        comun.guardar(obj);
    }

    @Override
    public void guardarAnclado(Anclado obj) {
        anclado.guardar(obj);
    }

    @Override
    public void guardarAdmor(Admor obj) {
        admor.guardar(obj);
    }

    @Override
    public void guardarNormal(Normal obj) {
        normal.guardar(obj);
    }

    @Override
    public Admor consultarAdmor(Admor obj) {
        return admor.consultarAdmor(obj);
    }

    @Override
    public Anclado consultarAnclado(Anclado obj) {
        return anclado.consultarAnclado(obj);
    }

    @Override
    public Comentario consultarComentario(Comentario obj) {
        return comentario.consultarComentario(obj);
    }

    @Override
    public Comun consultarComun(Comun obj) {
        return comun.consultarComun(obj);
    }

    @Override
    public Estado consultarEstado(Estado obj) {
        return estado.consultarEstado(obj);
    }

    @Override
    public Municipio consultarMunicipio(Municipio obj) {
        return municipio.consultarMunicipio(obj);
    }

    @Override
    public Normal consultarNormal(Normal obj) {
        return normal.consultarNormal(obj);
    }

    @Override
    public List<Admor> consultarAdmors() {
        return admor.consultarAdmors();
    }

    @Override
    public List<Anclado> consultarAnclados() {
        return anclado.consultarAnclados();
    }

    @Override
    public List<Comentario> consultarComentarios() {
        return comentario.consultarComentarios();
    }

    @Override
    public List<Comun> consultarComunes() {
        return comun.consultarComunes();
    }

    @Override
    public List<Estado> consultarEstados() {
        return estado.consultarEstados();
    }

    @Override
    public List<Municipio> consultarMunicipios() {
        return municipio.consultarMunicipios();
    }

    @Override
    public List<Normal> consultarNormales() {
        return normal.consultarNormales();
    }

    @Override
    public void editarAnclado(Anclado obj) {
         admor.editarAnclado(obj);
    }

    @Override
    public void borrarComun(Comun obj) {
        admor.eliminarComun(obj);
    }

    @Override
    public void borrarAnclado(Anclado obj) {
        admor.eliminarAnclado(obj);
    }

    @Override
    public void borrarComentario(Comentario obj) {
        admor.eliminarComentario(obj);
    }

    @Override
    public void editarComunAdmor(Comun obj) {
        admor.editarComunAdmor(obj);
    }

    @Override
    public void editarComunNormal(Comun obj) {
        normal.editarComunNormal(obj);
    }

    
}
