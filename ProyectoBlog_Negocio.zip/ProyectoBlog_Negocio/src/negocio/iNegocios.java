/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import dominio.Admor;
import dominio.Anclado;
import dominio.Comentario;
import dominio.Comun;
import dominio.Estado;
import dominio.Municipio;
import dominio.Normal;
import java.util.List;

/**
 *
 * @author palom
 */
public interface iNegocios {
    
    public void guardarComentario(Comentario obj);

    public void guardarComun(Comun obj);

    public void guardarAnclado(Anclado obj);

    public void guardarAdmor(Admor obj);

    public void guardarNormal(Normal obj);

    public Admor consultarAdmor(Admor obj);

    public Anclado consultarAnclado(Anclado obj);

    public Comentario consultarComentario(Comentario obj);
    
    public Comun consultarComun(Comun obj);

    public Estado consultarEstado(Estado obj);

    public Municipio consultarMunicipio(Municipio obj);

    public Normal consultarNormal(Normal obj);

    public List<Admor> consultarAdmors();

    public List<Anclado> consultarAnclados();

    public List<Comentario> consultarComentarios();

    public List<Comun> consultarComunes();

    public List<Estado> consultarEstados();

    public List<Municipio> consultarMunicipios();

    public List<Normal> consultarNormales();

    public void editarAnclado(Anclado obj);

    public void editarComunAdmor(Comun obj);
    
    public void editarComunNormal(Comun obj);

    public void borrarComun(Comun obj);

    public void borrarAnclado(Anclado obj);

    public void borrarComentario(Comentario obj);

}
